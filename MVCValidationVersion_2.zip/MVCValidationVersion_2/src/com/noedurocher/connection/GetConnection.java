package com.noedurocher.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetConnection {
	private static Connection conn;
	public PreparedStatement ps;
	public ResultSet rs;
	
	public static Connection getSQLConnection() {
		String url = "jdbc:postgresql://localhost:5432/PracticeJava";
		String user="postgres";
		String pwd = "Maradona85#";
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, user, pwd);
			return conn;
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
