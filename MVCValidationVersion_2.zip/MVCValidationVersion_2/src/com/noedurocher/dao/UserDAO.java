package com.noedurocher.dao;

import com.noedurocher.connection.GetConnection;

public class UserDAO {

	public boolean validateUser(String uname, String pwd) {
		// TODO Auto-generated method stub
		GetConnection c = new GetConnection();
		try {
			String sql = "select * from users where username=? and password=?;";
			c.ps = GetConnection.getSQLConnection().prepareStatement(sql);
			c.ps.setString(1, uname);
			c.ps.setString(2, pwd);
			c.rs = c.ps.executeQuery();
			
			return c.rs.next();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

}
